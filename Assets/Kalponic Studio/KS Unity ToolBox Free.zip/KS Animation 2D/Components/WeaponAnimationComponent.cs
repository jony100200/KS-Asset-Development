namespace KalponicStudio
{
    /// <summary>
    /// Drives weapon animations independently of the body.
    /// </summary>
    public sealed class WeaponAnimationComponent : AnimationComponentBase
    {
    }
}
