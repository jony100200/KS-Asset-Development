namespace KalponicStudio
{
    /// <summary>
    /// Drives effect/FX-specific animations.
    /// </summary>
    public sealed class EffectAnimationComponent : AnimationComponentBase
    {
    }
}
